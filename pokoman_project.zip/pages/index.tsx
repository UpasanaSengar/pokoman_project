import Head from "next/head";
import Header from "../components/Header";
import { Footer } from "../components/Footer";
import PokemonList from "../components/PokemonList";

export default function Home() {
  return (
    <>
      <Head>
        <title>Pokémon Explorer</title>
        <meta name="description" content="Explore Pokémon details" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <Header />
       <main className="flex flex-col min-h-screen pt-24">
        <div className="flex-grow px-4">
          <PokemonList />
        </div>
        <Footer />
      </main>
     
    </>
  );
}
