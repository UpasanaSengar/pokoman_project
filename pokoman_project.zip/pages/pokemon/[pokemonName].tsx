import { useRouter } from "next/router";
import dynamic from "next/dynamic";
import Head from "next/head";
import Header from "../../components/Header";
import { Footer } from "../../components/Footer";

const PokemonDetails = dynamic(() => import("../../components/PokemonDetails"), {
  ssr: false,
});

export default function PokemonDetailPage() {
  const router = useRouter();
  const { pokemonName } = router.query;

  return (
    <>
      <Head>
        <title>{pokemonName} - Pokémon</title>
        <meta name="description" content={`Details of ${pokemonName}`} />
      </Head>
         <main className="flex flex-col min-h-screen">
          <Header />
           <div className="flex-grow p-4 pt-24">
          {typeof pokemonName === "string" && (
            <PokemonDetails pokemonName={pokemonName} />
          )}
        </div> 

        <Footer />
      </main>
    </>
  );
}