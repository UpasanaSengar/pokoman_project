import React from "react";

export const StatsBar = ({ value }: { value: number }) => {
  const width = Math.min(value, 100); // max 100%
  const color = value >= 75 ? "bg-green-500" : value >= 50 ? "bg-yellow-400" : "bg-red-500";

  return (
    <div className="w-full bg-gray-200 rounded h-4 mt-1 mb-2">
      <div
        className={`h-4 rounded ${color}`}
        style={{ width: `${width}%` }}
      ></div>
    </div>
  );
};
