import React from "react";

export const Separator = ({ orientation = "horizontal" }: { orientation?: "horizontal" | "vertical" }) => {
  return (
    <div
      className={orientation === "vertical" ? "w-px h-full bg-gray-300 mx-2" : "h-px w-full bg-gray-300 my-2"}
    />
  );
};
