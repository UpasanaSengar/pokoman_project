import React from "react";
import clsx from "clsx";

export const Badge = ({
  children,
  type = "default",
  className,
}: {
  children: React.ReactNode;
  type?: string;
  className?: string;
}) => {
  const base = "inline-block px-2 py-1 rounded text-xs font-semibold capitalize";
  const colors: Record<string, string> = {
    fire: "bg-red-500 text-white",
    water: "bg-blue-500 text-white",
    grass: "bg-green-500 text-white",
    electric: "bg-yellow-400 text-black",
    bug: "bg-lime-500 text-black",
    poison: "bg-purple-500 text-white",
    default: "bg-gray-300 text-black",
  };

  return (
    <span className={clsx(base, colors[type] || colors.default, className)}>{children}</span>
  );
};
