"use client";
import React, { useEffect, useState } from "react";
import PokemonCard from "./PokemonCard";
import { useGetAllPokemonPage } from "../hooks/use-pokeapi";
import Loading from "./loading";
import { PokemonData } from "../types";
import usePaginationStore from "../store/store";
import { Button } from "../components/ui/button";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default function PokemonList() {
  const { currentPage, itemsPerPage, updatePagePosition } =
    usePaginationStore();

  const {
    isLoading,
    data: pokemonPage,
    error,
  } = useGetAllPokemonPage(itemsPerPage, currentPage);

  const [pokemonList, setPokemonList] = useState<PokemonData[]>([]);

  useEffect(() => {
    setPokemonList(pokemonPage ?? []);
  }, [pokemonPage]);

  if (isLoading) {
    return <Loading />;
  }

  if (error) {
    return <div>Error</div>;
  }

  return (
    <div className="relative">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {pokemonList.map((pokemon, index) => (
          <PokemonCard
            key={index}
            pokemonName={pokemon.name}
            pokemonImgUrl={`https://img.pokemondb.net/artwork/large/${pokemon.name}.jpg`}
          />
        ))}
      </div>

      <div className="fixed bottom-6 right-6 flex flex-row gap-4">
        <Button
          size="lg"
          variant="outline"
          onClick={() => updatePagePosition(-itemsPerPage)}
        >
          <FontAwesomeIcon icon="fa-solid fa-arrow-left" />
        </Button>
        <Button
          size="lg"
          variant="default"
          onClick={() => updatePagePosition(itemsPerPage)}
        >
          <FontAwesomeIcon icon="fa-solid fa-arrow-right" />
        </Button>
      </div>
    </div>
  );
}