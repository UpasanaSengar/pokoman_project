export default function Loading() {
  return (
    <div className="flex justify-center items-center h-40 text-xl font-semibold">
      Loading...
    </div>
  );
}