import React, { Suspense } from "react";
import Link from "next/link";
import { capitalize } from "../lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";

type Props = {
  pokemonName: string;
  pokemonImgUrl?: string;
};

export default function PokemonCard({ pokemonName, pokemonImgUrl }: Props) {
  return (
    <Link href={`/pokemon/${pokemonName}`}>
      <Card className="hover:shadow-lg transition-all cursor-pointer">
        <CardHeader>
          <CardTitle>{capitalize(pokemonName)}</CardTitle>
        </CardHeader>
        <CardContent className="flex justify-center">
          <Suspense fallback={<div>Loading...</div>}>
            <img
              className="w-36 h-36 object-contain"
              src={pokemonImgUrl}
              alt={`${pokemonName} image`}
            />
          </Suspense>
        </CardContent>
      </Card>
    </Link>
  );
}