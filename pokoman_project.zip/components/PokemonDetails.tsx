"use client";
import { useRouter } from "next/router";
import PokedataCard from "./PokedataCard";
import SpeciesInfo from "./SpeciesInfo";
import { Suspense } from "react";
import Loading from "./loading";
import { useGetPokemon } from "../hooks/use-pokeapi";
import { findPokemonDBImage } from "../lib/utils";

type Props = {
  pokemonName: string;
};

export default function PokemonDetails({ pokemonName }: Props) {
  const router = useRouter();
  const { data, isLoading, isError } = useGetPokemon(pokemonName);

  if (isLoading) return <Loading />;
  if (isError || !data) return <div>No Data Found</div>;

  return (
    <>
      <section className="flex h-full flex-col gap-10 md:flex-row md:grid-cols-2 pt-10">
        <div className="grid grid-cols-1 md:grid-cols-8">
          <div className="col-start-1 col-span-3">
            <PokedataCard
              pokemonData={data}
              pokemonImageURL={findPokemonDBImage(data.name)}
            />
          </div>
          <div className="md:col-start-4 md:col-span-full">
            <Suspense fallback={<Loading />}>
              <SpeciesInfo pokemonData={data} />
            </Suspense>
          </div>
        </div>
      </section>
      <button
        onClick={() => router.push("/")}
        className="fixed bottom-6 right-6 z-50 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded shadow-lg"
      >
        Back
      </button>
    </>
  );
}
