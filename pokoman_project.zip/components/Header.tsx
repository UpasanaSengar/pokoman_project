"use client";
import Link from "next/link";
import { useState, useEffect, KeyboardEvent } from "react";
import axios from "axios";
import { useRouter } from "next/router";

interface Pokemon {
  name: string;
  url: string;
}

export default function Header() {
  const [input, setInput] = useState("");
  const [suggestions, setSuggestions] = useState<Pokemon[]>([]);
  const router = useRouter();

  useEffect(() => {
    if (input.length > 0) {
      axios.get("https://pokeapi.co/api/v2/pokemon?limit=151").then((res) => {
        const filtered = res.data.results.filter((p: Pokemon) =>
          p.name.toLowerCase().includes(input.toLowerCase())
        );
        setSuggestions(filtered);
      });
    } else {
      setSuggestions([]);
    }
  }, [input]);

  const handleSearch = (name: string) => {
    if (name.trim() !== "") {
      setSuggestions([]);
      router.push(`/pokemon/${name.toLowerCase()}`);
      setInput("");
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSearch(input);
    }
  };

  return (
    <header className="fixed top-0 left-0 w-full z-50 flex flex-col sm:flex-row items-center justify-between bg-white p-4 shadow-md"> 

      {/* Logo */}
      <Link href="/">
        <div className="flex items-center gap-2 cursor-pointer">
          <img src="/logo.png" alt="logo" className="w-10 h-10" />
          <h1 className="text-2xl font-bold">PokeDex</h1>
        </div>
      </Link>

      {/* Search Bar */}
      <div className="flex items-center w-full sm:w-2/3 relative mt-4 sm:mt-0">
        <a
          href="https://github.com/UpasanaSengar"
          target="_blank"
          rel="noopener noreferrer"
        >
          <img src="/github.png" alt="GitHub" className="w-15 h-8 mr-3" />
        </a>

        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Search Pokémon..."
          className="w-full border p-2 rounded"
        />

        <button
          onClick={() => handleSearch(input)}
          className="ml-2 bg-blue-600 text-white px-4 py-2 rounded"
        >
          Search
        </button>

        {suggestions.length > 0 && (
          <ul className="absolute top-full left-8 z-10 bg-white border mt-1 w-full max-h-48 overflow-y-auto shadow-lg rounded">
            {suggestions.map((p, i) => (
              <li
                key={i}
                className="px-4 py-2 hover:bg-gray-100 cursor-pointer capitalize"
                onClick={() => handleSearch(p.name)}
              >
                {p.name}
              </li>
            ))}
          </ul>
        )}
      </div>
    </header>
  );
}