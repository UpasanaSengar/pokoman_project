import React from "react";

interface Props {
  value: number;
}

export const RatioBar = ({ value }: Props) => {
  const female = (value / 8) * 100;
  const male = 100 - female;

  return (
    <div className="flex w-full h-4 rounded overflow-hidden border border-gray-300">
      <div style={{ width: `${female}%` }} className="bg-pink-400" />
      <div style={{ width: `${male}%` }} className="bg-blue-400" />
    </div>
  );
};