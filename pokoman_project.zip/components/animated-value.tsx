
import React, { useEffect, useState } from "react";

interface Props {
  value: number;
  round?: number;
}

export const AnimatedValue = ({ value, round = 0 }: Props) => {
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    let start = 0;
    const duration = 1000;
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const newValue = value * progress;
      setDisplayValue(parseFloat(newValue.toFixed(round)));
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [value, round]);

  return <span>{displayValue}</span>;
};
