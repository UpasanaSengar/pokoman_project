import { create } from "zustand";

interface PaginationStore {
  currentPage: number;
  itemsPerPage: number;
  updatePagePosition: (by: number) => void;
}

const usePaginationStore = create<PaginationStore>((set) => ({
  currentPage: 0,
  itemsPerPage: 12,
  updatePagePosition: (by) => set((state) => ({
    currentPage: Math.max(0, state.currentPage + by)
  })),
}));

export default usePaginationStore;