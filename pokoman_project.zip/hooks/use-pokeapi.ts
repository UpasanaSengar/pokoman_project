import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { PokemonData } from "../types";

/**
 * Get a single Pokémon's full data
 */
export const useGetPokemon = (name: string) => {
  return useQuery<PokemonData>({
    queryKey: ["pokemon", name],
    queryFn: async () => {
      const { data } = await axios.get(`https://pokeapi.co/api/v2/pokemon/${name}`);
      return data;
    },
    enabled: !!name,
  });
};

/**
 * Get Pokémon species info for extra details
 */
export const useGetSpeciesInfo = (url: string) => {
  return useQuery({
    queryKey: ["species", url],
    queryFn: async () => {
      const { data } = await axios.get(url);
      return data;
    },
    enabled: !!url,
  });
};

/**
 * Get paginated list of Pokémon
 */
export const useGetAllPokemonPage = (limit = 12, offset = 0) => {
  return useQuery({
    queryKey: ["pokemonList", limit, offset],
    queryFn: async () => {
      const { data } = await axios.get(
        `https://pokeapi.co/api/v2/pokemon?limit=${limit}&offset=${offset}`
      );

      // Enrich with additional Pokémon data
      const results = await Promise.all(
        data.results.map(async (pokemon: { name: string }) => {
          const res = await axios.get(`https://pokeapi.co/api/v2/pokemon/${pokemon.name}`);
          return res.data;
        })
      );

      return results as PokemonData[];
    },
  });
};
